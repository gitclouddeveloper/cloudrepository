import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonutilititiesComponent } from './commonutilitities.component';

describe('CommonutilititiesComponent', () => {
  let component: CommonutilititiesComponent;
  let fixture: ComponentFixture<CommonutilititiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonutilititiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonutilititiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
