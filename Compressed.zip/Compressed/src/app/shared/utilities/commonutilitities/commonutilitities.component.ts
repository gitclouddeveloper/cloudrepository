import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commonutilitities',
  templateUrl: './commonutilitities.component.html',
  styleUrls: ['./commonutilitities.component.css']
})
export class CommonutilititiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
