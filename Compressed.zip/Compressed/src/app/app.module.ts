import { NgModule }       from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';

import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { InMemoryDataService }  from './in-memory-data.service';

import { AppRoutingModule }     from './app-routing.module';
import { JwtModule } from '@auth0/angular-jwt';

import { AppComponent }         from './app.component';
import { DashboardComponent }   from './navigational/dashboard/dashboard.component';
import { HeroDetailComponent }  from './navigational/hero-detail/hero-detail.component';
import { HeroesComponent }      from './navigational/heroes/heroes.component';
import { HeroSearchComponent }  from './navigational/hero-search/hero-search.component';
import { MessagesComponent }    from './navigational/messages/messages.component';
import { NavigationalComponent } from './navigational/navigational/navigational.component';
import { CommonutilititiesComponent } from './shared/utilities/commonutilitities/commonutilitities.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,

    JwtModule.forRoot({
      config: {
        tokenGetter: function  tokenGetter() {
             return     localStorage.getItem('access_token');},
        whitelistedDomains: ['localhost:4200'],
        blacklistedRoutes: ['http://localhost:4200/auth/login']
      }
    }),

    // The HttpClientInMemoryWebApiModule module intercepts HTTP requests
    // and returns simulated server responses.
    // Remove it when a real server is ready to receive requests.
    HttpClientInMemoryWebApiModule.forRoot(
      InMemoryDataService, { dataEncapsulation: false }
    )
  ],
  declarations: [
    AppComponent,
    DashboardComponent,
    HeroesComponent,
    HeroDetailComponent,
    MessagesComponent,
    HeroSearchComponent,
    NavigationalComponent,
    CommonutilititiesComponent
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
