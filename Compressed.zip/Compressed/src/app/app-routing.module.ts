import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { NavigationalComponent }   from './navigational/navigational/navigational.component';
import { DashboardComponent }   from './navigational/dashboard/dashboard.component';
import { HeroesComponent }      from './navigational/heroes/heroes.component';
import { HeroDetailComponent }  from './navigational/hero-detail/hero-detail.component';

const routes: Routes = [
  { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  { path: 'app', redirectTo: '/app', pathMatch: 'full' },
  { path: 'navigation', component: NavigationalComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'detail/:id', component: HeroDetailComponent },
  { path: 'heroes', component: HeroesComponent }
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
