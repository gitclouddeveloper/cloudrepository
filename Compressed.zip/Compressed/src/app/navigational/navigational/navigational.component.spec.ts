import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavigationalComponent } from './navigational.component';

describe('NavigationalComponent', () => {
  let component: NavigationalComponent;
  let fixture: ComponentFixture<NavigationalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavigationalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavigationalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
