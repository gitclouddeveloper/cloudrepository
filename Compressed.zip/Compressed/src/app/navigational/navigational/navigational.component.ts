import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigational',
  templateUrl: './navigational.component.html',
  styleUrls: ['./navigational.component.css']
})
export class NavigationalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
