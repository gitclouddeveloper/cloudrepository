import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
providedIn: 'root'
})

export class JwtService {
    constructor(private httpClient: HttpClient) { }

    /*
    * The login method to fetch the access token from server
    */
    login(email:string, password:string) {
      return this.httpClient.post<{access_token:  string}>('http://www.your-server.com/auth/login', {email, password}).pipe(tap(res => {
      localStorage.setItem('access_token', res.access_token);
    }))
  }

   /*
    * The register method to call register methid to 
    * to fetch the access token from server
    */
  register(email:string, password:string) {
    return this.httpClient.post<{access_token: string}>('http://www.your-server.com/auth/register', {email, password}).pipe(tap(res => {
    this.login(email, password)
  }))
}

   /*
    * The logout method to clear the access tokens of logins been done
    */
logout() {
  localStorage.removeItem('access_token');
}


   /*
    * The method to check whether the user is logged in or not
    */
  public get loggedIn(): boolean{
    return localStorage.getItem('access_token') !==  null;
  }

}
